<?php
session_start();
if (!isset($_SESSION['nik'])) {
 header("location:homepage.php");
}
$status = $_POST['status'];
$tanggapan = $_POST['tanggapan'];

include 'koneksi.php';
$tgl_tanggapan = date('Y-m-d');

$proses = $koneksi->query("insert into tanggapan values ('', '$tgl_tanggapan', '$nik', '$isi', '$nama_foto', '$status','$tanggapan)");

if($proses){
    header("Location:homepage_petugas.php");
}else {
    print_r($koneksi->errorInfo());
}
?>