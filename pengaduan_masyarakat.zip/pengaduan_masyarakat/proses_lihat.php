<?php
session_start();
if (!isset($_SESSION['id_tanggapan'])) {
 header("location:homepage_petugas.php");
}
$koneksi = new PDO("mysql:host=localhost;dbname=pengaduan_masyarakat", "root", "");

 $status = $_SESSION['status'];
 $id_pengaduan = $_SESSION['id_pengaduan'];
 $tgl_tanggapan = date('Y-m-d');
 $tanggapan = $_SESSION['tanggapan'];

$query = $koneksi->query("insert into pengaduan values ('','$status', '$id_pengaduan', '$tgl_pengaduan', '$tanggapan')");
$data = $query->fetch();

if($koneksi){
    header("location :homepage_petugas.php");
}else {
    print_r($koneksi->errorInfo());
}
?>