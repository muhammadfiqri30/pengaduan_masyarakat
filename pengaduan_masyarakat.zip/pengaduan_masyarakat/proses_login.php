<?php
session_start();
include "koneksi.php";

$username = $_POST['username'];
$password = $_POST['password'];
$query = $koneksi->query("SELECT * FROM masyarakat WHERE username = '$username' AND password ='$password'");

$jumlahBaris = $query->rowCount();

if ($jumlahBaris > 0) {

    $data = $query->fetch();
    
    $_SESSION['nik'] = $data['nik'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['level'] = 'masyarakat';

    header("location:homepage.php");
}else{
    $query = $koneksi->query("SELECT * FROM petugas WHERE username = '$username' AND password ='$password'");
    $jumlahBaris = $query->rowCount();

    if($jumlahBaris > 0) {

        $data = $query->fetch();
        $_SESSION["id_petugas"] = $data['id_petugas'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['level'] = $data['level'];
    
        header("location:homepage_petugas.php");

 }else{
     header("location:login.php");
  }
}
?>