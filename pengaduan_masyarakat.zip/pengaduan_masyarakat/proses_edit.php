<?php
$nama_foto = $_FILES['foto']['name'];
$asal_foto = $_FILES['foto']['tmp_name'];
move_uploaded_file($asal_foto, "foto/$nama_foto");

$isi_laporan = $_POST['isi_laporan'];
$id = $_GET['id'];

$koneksi = new PDO("mysql:host=localhost;dbname=pengaduan_masyarakat","root", "");

$query = $koneksi->query("UPDATE `pengaduan` set isi_laporan='$isi_laporan', foto='$nama_foto' where id_pengaduan='$id'");

if($koneksi){
    header("location:homepage.php");
}else {
    print_r($koneksi->errorInfo());
}
?>