<?php
    $servername = "localhost";
    $database = "pengaduan_masyarakat";
    $username = "root";
    $password = "";

    $koneksi = $koneksi->query($servername, $databse, $username, $password);

    if($koneksi){
        header("Location:login.php");
    }else {
        echo "Login failed";
    }

?>