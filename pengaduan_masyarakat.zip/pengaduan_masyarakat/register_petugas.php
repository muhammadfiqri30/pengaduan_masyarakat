<?php 
    require "koneksi.php";
    $nama = $_POST['nama'];
    $telp = $_POST['telp'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $level = "petugas";


    $query_sql = "INSERT INTO petugas (nama_petugas,telp,username,password,level) VALUES ('$nama','$telp','$username','$password','$level')";

    if ($koneksi->query ($query_sql)){
        header("Location:login.php");
    }else {
        echo "pendaftaran gagal :". $koneksi->errorInfo();
    }
?>