<?php 
    require "koneksi.php";
    $nama = $_POST['nama'];
    $nik = $_POST['nik'];
    $telp = $_POST['telp'];
    $username = $_POST['username'];
    $password = $_POST['password'];


    $query_sql = "INSERT INTO masyarakat (nik,nama,username,password,telp) VALUES ('$nik','$nama','$username','$password','$telp')";

    if ($koneksi->query ($query_sql)){
        header("Location:login.php");
    }else {
        echo "pendaftaran gagal :". $koneksi->errorInfo();
    }
?>